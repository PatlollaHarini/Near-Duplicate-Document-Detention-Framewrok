import java.util.*;

class Shingling {

    static Set<String> generateWordShingles(String text, int k) {
        List<String> words = TextPreprocessor.tokenize(text);
        Set<String> shingles = new HashSet<>();

        if (k <= 0 || words.size() < k) return shingles;

        for (int i = 0; i <= words.size() - k; i++) {
            StringBuilder shingle = new StringBuilder();

            for (int j = i; j < i + k; j++) {
                if (j > i) shingle.append("_");
                shingle.append(words.get(j));
            }

            shingles.add(shingle.toString());
        }

        return shingles;
    }
}
