import java.util.*;

class Document {
    String name;
    String originalText;
    String cleanedText;
    Set<String> shingles = new HashSet<>();
    long simHash;
    int[] minHash;

    Document(String name, String originalText) {
        this.name = name;
        this.originalText = originalText;
    }
}
