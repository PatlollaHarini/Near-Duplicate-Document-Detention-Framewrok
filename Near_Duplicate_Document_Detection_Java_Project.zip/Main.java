import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Near-Duplicate Document Detection Framework ===");
        System.out.print("Enter number of documents: ");
        int n = Integer.parseInt(sc.nextLine());

        List<Document> docs = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            System.out.print("Enter document name " + (i + 1) + ": ");
            String name = sc.nextLine();

            System.out.println("Enter document text:");
            String text = sc.nextLine();

            docs.add(new Document(name, text));
        }

        System.out.print("Enter shingle size k (recommended 3-5): ");
        int k = Integer.parseInt(sc.nextLine());

        SimilarityEngine engine = new SimilarityEngine(k);

        System.out.println("\n--- DOCUMENT SIGNATURES ---");
        for (Document d : docs) {
            engine.prepare(d);
            System.out.println("\n" + d.name);
            System.out.println("Clean text : " + d.cleanedText);
            System.out.println("Shingles   : " + d.shingles);
            System.out.println("SimHash    : " + d.simHash);
            System.out.println("MinHash    : " + Arrays.toString(d.minHash));
        }

        System.out.println("\n--- PAIRWISE SIMILARITY REPORT ---");
        for (int i = 0; i < docs.size(); i++) {
            for (int j = i + 1; j < docs.size(); j++) {
                Document a = docs.get(i);
                Document b = docs.get(j);

                double jaccard = engine.jaccard(a, b);
                double cosine = engine.cosine(a, b);
                double simHashSimilarity = engine.simHashSimilarity(a, b);
                double minHashEstimate = engine.minHashSimilarity(a, b);

                // A practical combined decision rule for this demo.
                boolean duplicate =
                        jaccard >= 0.50 ||
                        cosine >= 0.70 ||
                        simHashSimilarity >= 0.85 ||
                        minHashEstimate >= 0.50;

                System.out.println("\n" + a.name + " <-> " + b.name);
                System.out.printf("Jaccard           : %.4f%n", jaccard);
                System.out.printf("Cosine            : %.4f%n", cosine);
                System.out.printf("SimHash similarity: %.4f%n", simHashSimilarity);
                System.out.printf("MinHash estimate  : %.4f%n", minHashEstimate);
                System.out.println("Decision          : " +
                        (duplicate ? "NEAR-DUPLICATE" : "DIFFERENT"));
            }
        }

        sc.close();
    }
}
