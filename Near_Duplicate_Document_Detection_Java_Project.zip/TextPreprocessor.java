import java.util.*;

class TextPreprocessor {

    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
        "a", "an", "the", "is", "are", "was", "were",
        "of", "to", "in", "on", "for", "and", "or",
        "with", "as", "by", "this", "that", "it"
    ));

    static String clean(String text) {
        if (text == null) return "";

        String normalized = text
                .toLowerCase()
                .replaceAll("[^a-z0-9\\s]", " ")
                .replaceAll("\\s+", " ")
                .trim();

        StringBuilder result = new StringBuilder();

        for (String word : normalized.split("\\s+")) {
            if (!word.isEmpty() && !STOP_WORDS.contains(word)) {
                result.append(word).append(" ");
            }
        }

        return result.toString().trim();
    }

    static List<String> tokenize(String text) {
        if (text == null || text.isBlank()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(text.split("\\s+")));
    }
}
