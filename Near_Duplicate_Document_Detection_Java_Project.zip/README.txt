NEAR-DUPLICATE DOCUMENT DETECTION FRAMEWORK
============================================

Project flow:
RAW TEXT
   -> PREPROCESSING
   -> SHINGLING
   -> SIMHASH / MINHASH
   -> SIMILARITY
   -> THRESHOLD DECISION
   -> REPORT

Algorithms implemented:
1. Text normalization
2. Tokenization
3. Stop-word removal
4. Word-based k-shingling
5. Jaccard similarity
6. Cosine similarity
7. SimHash fingerprint
8. MinHash signature
9. Threshold-based duplicate detection

HOW TO RUN
----------
Open Command Prompt in this folder.

Compile:
    javac *.java

Run:
    java Main

Example:
    Number of documents: 3

    Document 1:
    "Machine learning is used for detecting duplicate documents"

    Document 2:
    "Machine learning is useful for detecting duplicate documents"

    Document 3:
    "The weather is pleasant and sunny today"

Recommended k:
    3 or 4

IMPORTANT
---------
The thresholds in Main.java are demonstration values:
    Jaccard >= 0.50
    Cosine >= 0.70
    SimHash similarity >= 0.85
    MinHash estimate >= 0.50

For a real dataset, thresholds should be tuned using validation data.

DSA CONNECTION
--------------
Sets:
    Store unique shingles and calculate union/intersection.

Hashing:
    Compact fingerprints using SimHash and MinHash.

Arrays:
    Store SimHash bit weights and MinHash signatures.

HashMap:
    Store term frequencies.

Bit operations:
    Calculate SimHash and Hamming distance.

Time complexity:
    Preprocessing is approximately O(L), where L is the text length.
    Shingling is approximately O(W), where W is the number of words.
    Jaccard uses set operations.
    Pairwise comparison over N documents is O(N^2) pairs.

This code is designed as a college DSA project/demo and can be extended
with file input, CSV reports, a GUI, or a database.
