import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

class SimilarityEngine {

    private final int k;
    private static final int MINHASH_SIZE = 64;

    SimilarityEngine(int k) {
        this.k = k;
    }

    void prepare(Document d) {
        d.cleanedText = TextPreprocessor.clean(d.originalText);
        d.shingles = Shingling.generateWordShingles(d.cleanedText, k);
        d.simHash = simHash(d.shingles);
        d.minHash = minHash(d.shingles);
    }

    double jaccard(Document a, Document b) {
        if (a.shingles.isEmpty() && b.shingles.isEmpty()) return 1.0;

        Set<String> union = new HashSet<>(a.shingles);
        union.addAll(b.shingles);

        Set<String> intersection = new HashSet<>(a.shingles);
        intersection.retainAll(b.shingles);

        return union.isEmpty() ? 0.0 :
                (double) intersection.size() / union.size();
    }

    double cosine(Document a, Document b) {
        Map<String, Integer> va = termFrequency(a.cleanedText);
        Map<String, Integer> vb = termFrequency(b.cleanedText);

        Set<String> terms = new HashSet<>(va.keySet());
        terms.addAll(vb.keySet());

        double dot = 0;
        double normA = 0;
        double normB = 0;

        for (String term : terms) {
            int x = va.getOrDefault(term, 0);
            int y = vb.getOrDefault(term, 0);

            dot += x * y;
            normA += x * x;
            normB += y * y;
        }

        if (normA == 0 || normB == 0) return 0.0;

        return dot / (Math.sqrt(normA) * Math.sqrt(normB));
    }

    double simHashSimilarity(Document a, Document b) {
        int distance = Long.bitCount(a.simHash ^ b.simHash);
        return 1.0 - (distance / 64.0);
    }

    double minHashSimilarity(Document a, Document b) {
        int equal = 0;

        for (int i = 0; i < MINHASH_SIZE; i++) {
            if (a.minHash[i] == b.minHash[i]) {
                equal++;
            }
        }

        return (double) equal / MINHASH_SIZE;
    }

    private Map<String, Integer> termFrequency(String text) {
        Map<String, Integer> map = new HashMap<>();

        for (String word : TextPreprocessor.tokenize(text)) {
            map.put(word, map.getOrDefault(word, 0) + 1);
        }

        return map;
    }

    // SimHash: each shingle contributes to 64 bit positions.
    private long simHash(Set<String> shingles) {
        if (shingles.isEmpty()) return 0L;

        int[] weights = new int[64];

        for (String shingle : shingles) {
            long hash = hash64(shingle);

            for (int bit = 0; bit < 64; bit++) {
                if (((hash >>> bit) & 1L) == 1L) {
                    weights[bit]++;
                } else {
                    weights[bit]--;
                }
            }
        }

        long fingerprint = 0L;

        for (int bit = 0; bit < 64; bit++) {
            if (weights[bit] >= 0) {
                fingerprint |= (1L << bit);
            }
        }

        return fingerprint;
    }

    // MinHash: minimum hash value for each permutation/seed.
    private int[] minHash(Set<String> shingles) {
        int[] signature = new int[MINHASH_SIZE];
        Arrays.fill(signature, Integer.MAX_VALUE);

        for (String shingle : shingles) {
            for (int i = 0; i < MINHASH_SIZE; i++) {
                int h = hash32(shingle, i);
                if (h < signature[i]) {
                    signature[i] = h;
                }
            }
        }

        return signature;
    }

    private int hash32(String s, int seed) {
        int h = 0x811c9dc5 ^ seed * 0x9e3779b9;

        for (byte b : s.getBytes(StandardCharsets.UTF_8)) {
            h ^= b;
            h *= 0x01000193;
            h ^= (h >>> 13);
        }

        return h;
    }

    private long hash64(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(s.getBytes(StandardCharsets.UTF_8));

            long result = 0;
            for (int i = 0; i < 8; i++) {
                result = (result << 8) | (bytes[i] & 0xffL);
            }

            return result;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}
